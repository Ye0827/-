package cn.itcast.cshiyong;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class MainActivity extends Activity {


    Button add;
    ImageView cat;

    private ListView mListView;
    private String[] titles = { "孟加拉猫" , "暹罗猫","英短蓝猫"," 蓝猫","布偶猫","英国短毛猫","英短蓝猫幼猫","纯种英国短毛猫","纯种英短幼猫","加菲猫"};
    private String[] prices = { "￥15999","￥5299","￥1899", "￥2099","￥6500","￥1450","￥998","￥10000","￥1500","￥4299"};
    private  int[] icons = {R.drawable.a,R.drawable.b,R.drawable.c,R.drawable.d
            ,R.drawable.e,R.drawable.f ,R.drawable.g ,R.drawable.h ,R.drawable.j ,R.drawable.k};
    protected  void  onCreate(Bundle savedInstanState) {
        super.onCreate(savedInstanState);
        setContentView(R.layout.activity_main);
        mListView = (ListView) findViewById(R.id.lv);


        MyBaseAdapter mAdapter = new MyBaseAdapter();
        mListView.setAdapter(mAdapter);


        cat=(ImageView)findViewById(R.id.cat);

    cat.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent=new Intent(MainActivity.this,catActivity.class);
            startActivity(intent);
        }
    });

    }





    class MyBaseAdapter extends  BaseAdapter {
            @Override
            public int getCount(){
                return  titles.length;
            }
            @Override
            public Object getItem(int position) {
                return  titles[position];
            }
            @Override
            public long getItemId(int position) {
                return  position;
            }
            @Override
            public View getView(int position, View convertView,ViewGroup parent) {
                View view = View.inflate(MainActivity.this,R.layout.list_item,null);
            TextView title = (TextView) view.findViewById(R.id.title);
            TextView price = (TextView) view.findViewById(R.id.price);
            ImageView iv = (ImageView) view.findViewById(R.id.iv);
            title.setText(titles[position]);
            price.setText(prices[position]);
            iv.setBackgroundResource(icons[position]);
            return view;
        }
    }








}